package parcial1.model;
import java.util.LinkedList;
import java.util.Queue;

public class orderBook {
    private final Queue<transaccion> queue = new LinkedList<>();

    // Agregar orden al final de la cola
    public boolean addOrder(transaccion tx) {
        return queue.add(tx); // lanza excepción si falla
    }

    // Eliminar y devolver la primera orden
    public transaccion removeOrder() {
        return queue.poll(); // devuelve null si está vacía
    }

    // Ver la primera orden sin eliminarla
    public transaccion peekOrder() {
        return queue.peek(); // devuelve null si está vacía
    }

    // Saber si la cola está vacía
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    // Cantidad de órdenes en la cola
    public int size() {
        return queue.size();
    }

@Override

    public String toString() {
    
    return "OrderBook con " + size() + " órdenes en espera";
}
}


